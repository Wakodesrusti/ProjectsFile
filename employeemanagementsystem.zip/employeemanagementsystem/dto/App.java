package com.jspiders.employeemanagementsystem.dto;

public class App {

}

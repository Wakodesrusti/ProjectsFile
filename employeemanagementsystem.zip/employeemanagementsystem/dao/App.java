package com.jspiders.employeemanagementsystem.dao;

public class App {

}

package com.jspiders.employeemanagementsystem.main;

public class App {

}
